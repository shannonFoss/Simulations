public interface Ordered
{
	int compare(Object obj);
}